export { default } from './GithubCorner';
